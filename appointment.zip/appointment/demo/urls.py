from django.urls import path
from . import views

urlpatterns = [
    path('', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('signup/', views.signup, name='signup'),
    path('usersearch/', views.usersearch, name='usersearch'),
    path('applynurse/', views.applynurse, name='applynurse'),
    path('booknurse/<int:A>', views.booknurse, name='booknurse'),
    path('status/', views.status, name='status'),
    path('delete/<int:B>', views.deleteshedule, name='delete'),
    path('addnurse/', views.addnurse, name='addnurse'),
    path('nursedatabase/', views.nursedatabase, name='nursedatabase'),
    path('userdatabase/', views.userdatabase, name='userdatbase'),
    path('detail/', views.nursedetail, name='detail'),
    path('pationtnotify/', views.pationtnotify, name='alert'),
]